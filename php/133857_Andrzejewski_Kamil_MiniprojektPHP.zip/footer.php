<br/>
<br/>
<br/>
Kamil Andrzejewski<br/>
nr. 133857<br/>
Semestr V grupa 1b, Studia Niestacjonarne<br/>
Kierunek Informatyka<br/>
Wydział Informatyczny
</body>
</html>
<?php
mysqli_close($link);
?>